Site básico feito para aula de desenvolvimento web (HTML/CSS)
